package dev.luminos.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Drag-and-drop HUD editor.
 * <ul>
 *   <li>Drag a module with the left mouse button</li>
 *   <li>Right-click toggles it on/off</li>
 *   <li>Mouse wheel over a module changes its size</li>
 * </ul>
 */
public final class HudEditorScreen extends class_437 {
	private final class_437 parent;
	private HudModule dragging;
	private int grabX;
	private int grabY;

	public HudEditorScreen(class_437 parent) {
		super(class_2561.method_43470("Luminos HUD editor"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		int cx = field_22789 / 2;
		method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> method_25419()).method_46434(cx - 155, field_22790 - 28, 100, 20).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Reset layout"), b -> {
			Config.get().resetLayout();
			Config.save();
		}).method_46434(cx - 50, field_22790 - 28, 100, 20).method_46431());
		method_37063(class_4185.method_46430(label(), b -> {
			Config.get().showBackground = !Config.get().showBackground;
			b.method_25355(label());
			Config.save();
		}).method_46434(cx + 55, field_22790 - 28, 100, 20).method_46431());
		method_37063(class_4185.method_46430(zoomLabel(), b -> {
			Config c = Config.get();
			c.zoomFov = c.zoomFov >= 70 ? 20 : c.zoomFov + 10;
			c.zoomFov = Math.max(30, c.zoomFov);
			b.method_25355(zoomLabel());
			Config.save();
		}).method_46434(cx - 155, field_22790 - 52, 150, 20).method_46431());
		method_37063(class_4185.method_46430(sprintLabel(), b -> {
			Config.get().toggleSprint = !Config.get().toggleSprint;
			b.method_25355(sprintLabel());
			Config.save();
		}).method_46434(cx + 5, field_22790 - 52, 150, 20).method_46431());
	}

	private static class_2561 label() {
		return class_2561.method_43470("Backgrounds: " + (Config.get().showBackground ? "on" : "off"));
	}

	private static class_2561 zoomLabel() {
		return class_2561.method_43470("Zoom FOV: " + Config.get().zoomFov);
	}

	private static class_2561 sprintLabel() {
		return class_2561.method_43470("Toggle sprint: " + (Config.get().toggleSprint ? "on" : "off"));
	}

	@Override
	public void method_25394(class_332 g, int mouseX, int mouseY, float partial) {
		super.method_25394(g, mouseX, mouseY, partial);
		class_310 mc = class_310.method_1551();
		g.method_25300(field_22793, "Drag to move · Right-click to toggle · Scroll to resize", field_22789 / 2, 12, 0xFFE8EEFF);
		for (HudModule m : Modules.ALL) {
			Config.ModuleCfg c = Config.get().of(m);
			int w = (int) (m.width(mc) * c.scale);
			int h = (int) (m.height(mc) * c.scale);
			clamp(m, c);
			if (c.enabled) {
				LuminosClient.drawOne(g, mc, m, c, true);
			}
			boolean hover = mouseX >= c.x && mouseX <= c.x + w && mouseY >= c.y && mouseY <= c.y + h;
			int col = m == dragging ? 0xFF9BBCFF : hover ? 0xFF4F8CFF : c.enabled ? 0x664F8CFF : 0x66FF6B6B;
			g.method_49601(c.x - 1, c.y - 1, w + 2, h + 2, col);
			if (!c.enabled || hover) {
				g.method_51433(field_22793, m.title() + (c.enabled ? "" : " (off)"), c.x, c.y - 10, c.enabled ? 0xFF9BBCFF : 0xFFFF9B9B, true);
			}
		}
	}

	private void clamp(HudModule m, Config.ModuleCfg c) {
		class_310 mc = class_310.method_1551();
		c.x = Math.max(0, Math.min(c.x, field_22789 - (int) (m.width(mc) * c.scale)));
		c.y = Math.max(0, Math.min(c.y, field_22790 - (int) (m.height(mc) * c.scale)));
	}

	private HudModule hit(double mx, double my) {
		class_310 mc = class_310.method_1551();
		for (int i = Modules.ALL.size() - 1; i >= 0; i--) {
			HudModule m = Modules.ALL.get(i);
			Config.ModuleCfg c = Config.get().of(m);
			if (mx >= c.x && mx <= c.x + m.width(mc) * c.scale && my >= c.y && my <= c.y + m.height(mc) * c.scale) return m;
		}
		return null;
	}

	@Override
	public boolean method_25402(double mx, double my, int button) {
		if (super.method_25402(mx, my, button)) return true;
		HudModule m = hit(mx, my);
		if (m == null) return false;
		Config.ModuleCfg c = Config.get().of(m);
		if (button == 1) {
			c.enabled = !c.enabled;
			Config.save();
			return true;
		}
		if (button == 0) {
			dragging = m;
			grabX = (int) mx - c.x;
			grabY = (int) my - c.y;
			return true;
		}
		return false;
	}

	@Override
	public boolean method_25403(double mx, double my, int button, double dx, double dy) {
		if (dragging != null && button == 0) {
			Config.ModuleCfg c = Config.get().of(dragging);
			c.x = (int) mx - grabX;
			c.y = (int) my - grabY;
			return true;
		}
		return super.method_25403(mx, my, button, dx, dy);
	}

	@Override
	public boolean method_25406(double mx, double my, int button) {
		if (dragging != null) {
			dragging = null;
			Config.save();
			return true;
		}
		return super.method_25406(mx, my, button);
	}

	@Override
	public boolean method_25401(double mx, double my, double sx, double sy) {
		HudModule m = hit(mx, my);
		if (m != null) {
			Config.ModuleCfg c = Config.get().of(m);
			c.scale = Math.max(0.5f, Math.min(2.5f, c.scale + (sy > 0 ? 0.1f : -0.1f)));
			c.scale = Math.round(c.scale * 10f) / 10f;
			Config.save();
			return true;
		}
		return super.method_25401(mx, my, sx, sy);
	}

	@Override
	public void method_25419() {
		Config.save();
		class_310.method_1551().method_1507(parent);
	}
}
