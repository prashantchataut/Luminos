package dev.luminos.client;

import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * A movable on-screen widget. Modules draw at (0,0); the host translates and scales them,
 * so a module only has to describe its own size and contents.
 */
public abstract class HudModule {
	protected static final int TEXT = 0xFFE8EEFF;
	protected static final int DIM = 0xFF8596C5;
	protected static final int ACCENT = 0xFF4F8CFF;
	protected static final int PANEL = 0x99080D20;
	protected static final int PANEL_ON = 0xCC2C4F9C;

	public abstract String id();

	public abstract String title();

	/** Width in unscaled GUI pixels. */
	public abstract int width(class_310 mc);

	public abstract int height(class_310 mc);

	/** @param preview true inside the editor or when no world is loaded: use sample data. */
	public abstract void render(class_332 g, class_310 mc, boolean preview);

	public int defaultX() {
		return 6;
	}

	public int defaultY() {
		return 6;
	}

	public boolean enabledByDefault() {
		return true;
	}

	protected void panel(class_332 g, int w, int h) {
		if (Config.get().showBackground) {
			g.method_25294(0, 0, w, h, PANEL);
			g.method_25294(0, 0, 2, h, ACCENT);
		}
	}
}
