package dev.luminos.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWMouseButtonCallbackI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Entry point: config, key bindings, HUD host, CPS hook, toggle sprint and zoom. */
public final class LuminosClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("LuminosClient");
	private static final String CATEGORY = "key.categories.luminos";

	public static class_304 openEditor;
	private static class_304 zoomKey;
	private static class_304 sprintKey;

	public static boolean sprintLatched = false;
	private static boolean zooming = false;
	private static int savedFov = -1;

	@Override
	public void onInitializeClient() {
		Config.load();
		openEditor = KeyBindingHelper.registerKeyBinding(new class_304("key.luminos.editor", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
		zoomKey = KeyBindingHelper.registerKeyBinding(new class_304("key.luminos.zoom", class_3675.class_307.field_1668, GLFW.GLFW_KEY_C, CATEGORY));
		sprintKey = KeyBindingHelper.registerKeyBinding(new class_304("key.luminos.toggle_sprint", class_3675.class_307.field_1668, GLFW.GLFW_KEY_V, CATEGORY));

		HudRenderCallback.EVENT.register(LuminosClient::renderHud);
		ClientTickEvents.END_CLIENT_TICK.register(LuminosClient::tick);
		ClientLifecycleEvents.CLIENT_STARTED.register(LuminosClient::hookMouse);
		ClientLifecycleEvents.CLIENT_STOPPING.register(c -> {
			restoreFov(c);
			Config.save();
		});
		LOGGER.info("Luminos Client loaded — press Right Shift to edit the HUD");
	}

	/** Chain onto GLFW's mouse callback so we see every click, however fast, without a mixin. */
	private static void hookMouse(class_310 mc) {
		long window = mc.method_22683().method_4490();
		final GLFWMouseButtonCallbackI[] prev = new GLFWMouseButtonCallbackI[1];
		prev[0] = GLFW.glfwSetMouseButtonCallback(window, (w, button, action, mods) -> {
			if (action == GLFW.GLFW_PRESS) Modules.Cps.click(button);
			if (prev[0] != null) prev[0].invoke(w, button, action, mods);
		});
	}

	private static void renderHud(class_332 g, net.minecraft.class_9779 delta) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1690.field_1842 || mc.field_1755 instanceof HudEditorScreen) return;
		drawAll(g, mc, mc.field_1724 == null);
	}

	/** Draws every enabled module at its configured position. */
	static void drawAll(class_332 g, class_310 mc, boolean preview) {
		for (HudModule m : Modules.ALL) {
			Config.ModuleCfg c = Config.get().of(m);
			if (!c.enabled) continue;
			drawOne(g, mc, m, c, preview);
		}
	}

	static void drawOne(class_332 g, class_310 mc, HudModule m, Config.ModuleCfg c, boolean preview) {
		int sw = g.method_51421();
		int sh = g.method_51443();
		int x = Math.max(0, Math.min(c.x, sw - (int) (m.width(mc) * c.scale)));
		int y = Math.max(0, Math.min(c.y, sh - (int) (m.height(mc) * c.scale)));
		g.method_51448().method_22903();
		g.method_51448().method_46416(x, y, 0);
		g.method_51448().method_22905(c.scale, c.scale, 1f);
		m.render(g, mc, preview);
		g.method_51448().method_22909();
	}

	private static void tick(class_310 mc) {
		while (openEditor.method_1436()) {
			if (mc.field_1755 == null) mc.method_1507(new HudEditorScreen(null));
		}
		while (sprintKey.method_1436()) {
			Config.get().toggleSprint = !Config.get().toggleSprint;
			sprintLatched = false;
			if (mc.field_1724 != null) mc.field_1724.method_7353(net.minecraft.class_2561.method_43470("Luminos: toggle sprint " + (Config.get().toggleSprint ? "ON" : "OFF")), true);
			Config.save();
		}
		if (mc.field_1724 == null) {
			sprintLatched = false;
			return;
		}
		// Toggle sprint: once the player starts walking forward, keep sprint held until they stop.
		if (Config.get().toggleSprint && mc.field_1755 == null) {
			if (mc.field_1690.field_1894.method_1434()) {
				sprintLatched = true;
				mc.field_1690.field_1867.method_23481(true);
			} else if (sprintLatched) {
				sprintLatched = false;
				mc.field_1690.field_1867.method_23481(false);
			}
		}
		// Zoom: hold the key to narrow the FOV, release to restore the player's own value.
		boolean want = zoomKey.method_1434() && mc.field_1755 == null;
		if (want && !zooming) {
			savedFov = mc.field_1690.method_41808().method_41753();
			zooming = true;
		}
		if (zooming) {
			if (want) {
				mc.field_1690.method_41808().method_41748(Math.max(30, Math.min(110, Config.get().zoomFov)));
			} else {
				restoreFov(mc);
			}
		}
	}

	private static void restoreFov(class_310 mc) {
		if (zooming && savedFov > 0 && mc.field_1690 != null) mc.field_1690.method_41808().method_41748(savedFov);
		zooming = false;
	}
}
