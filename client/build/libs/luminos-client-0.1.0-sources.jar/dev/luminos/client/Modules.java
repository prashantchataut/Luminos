package dev.luminos.client;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_332;

/** Every built-in HUD module. */
public final class Modules {
	private Modules() {}

	public static final List<HudModule> ALL = List.of(
		new ArmorHud(), new Keystrokes(), new Cps(), new Fps(), new Coordinates(), new Potions(), new SprintStatus());

	// ---------------------------------------------------------------- Armor HUD
	public static final class ArmorHud extends HudModule {
		private static final class_1304[] SLOTS = {
			class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6173};

		public String id() { return "armor_hud"; }
		public String title() { return "Armor HUD"; }
		public int width(class_310 mc) { return 62; }
		public int height(class_310 mc) { return 5 * 18 + 2; }
		public int defaultX() { return 6; }
		public int defaultY() { return 90; }

		public void render(class_332 g, class_310 mc, boolean preview) {
			panel(g, width(mc), height(mc));
			for (int i = 0; i < SLOTS.length; i++) {
				class_1799 s = stack(mc, i, preview);
				int y = 2 + i * 18;
				if (s.method_7960()) continue;
				g.method_51427(s, 6, y);
				g.method_51431(mc.field_1772, s, 6, y);
				String label = null;
				int color = TEXT;
				if (s.method_7963()) {
					label = Integer.toString(s.method_7936() - s.method_7919());
					color = 0xFF000000 | s.method_31580();
				} else if (s.method_7947() > 1) {
					label = "x" + s.method_7947();
				}
				if (label != null) g.method_51433(mc.field_1772, label, 28, y + 5, color, true);
			}
		}

		private static class_1799 stack(class_310 mc, int i, boolean preview) {
			if (mc.field_1724 == null) {
				if (!preview) return class_1799.field_8037;
				class_1799[] demo = {
					new class_1799(class_1802.field_22027), new class_1799(class_1802.field_8058),
					new class_1799(class_1802.field_8396), new class_1799(class_1802.field_8753), new class_1799(class_1802.field_8802)};
				if (i < 4) demo[i].method_7974(30 * (i + 1));
				return demo[i];
			}
			return mc.field_1724.method_6118(SLOTS[i]);
		}
	}

	// ---------------------------------------------------------------- Keystrokes
	public static final class Keystrokes extends HudModule {
		public String id() { return "keystrokes"; }
		public String title() { return "Keystrokes"; }
		public int width(class_310 mc) { return 72; }
		public int height(class_310 mc) { return 68; }
		public int defaultX() { return 6; }
		public int defaultY() { return 160; }

		public void render(class_332 g, class_310 mc, boolean preview) {
			var o = mc.field_1690;
			key(g, mc, 25, 0, 22, 22, "W", o.field_1894.method_1434() || (preview && mc.field_1724 == null));
			key(g, mc, 0, 25, 22, 22, "A", o.field_1913.method_1434());
			key(g, mc, 25, 25, 22, 22, "S", o.field_1881.method_1434());
			key(g, mc, 50, 25, 22, 22, "D", o.field_1849.method_1434());
			long w = mc.method_22683().method_4490();
			boolean l = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
			boolean r = GLFW.glfwGetMouseButton(w, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
			key(g, mc, 0, 50, 35, 18, "LMB " + Cps.left(), l);
			key(g, mc, 37, 50, 35, 18, "RMB " + Cps.right(), r);
		}

		private void key(class_332 g, class_310 mc, int x, int y, int w, int h, String label, boolean down) {
			g.method_25294(x, y, x + w, y + h, down ? PANEL_ON : PANEL);
			if (down) g.method_25294(x, y + h - 2, x + w, y + h, ACCENT);
			int tw = mc.field_1772.method_1727(label);
			g.method_51433(mc.field_1772, label, x + (w - tw) / 2, y + (h - 8) / 2, down ? 0xFFFFFFFF : TEXT, false);
		}
	}

	// ---------------------------------------------------------------- CPS
	public static final class Cps extends HudModule {
		private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
		private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();

		/** Called from the GLFW mouse-button hook installed by {@link LuminosClient}. */
		public static void click(int button) {
			long now = System.currentTimeMillis();
			if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) LEFT.addLast(now);
			if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) RIGHT.addLast(now);
		}

		private static int count(ArrayDeque<Long> q) {
			long cutoff = System.currentTimeMillis() - 1000;
			while (!q.isEmpty() && q.peekFirst() < cutoff) q.pollFirst();
			return q.size();
		}

		public static int left() { return count(LEFT); }
		public static int right() { return count(RIGHT); }

		public String id() { return "cps"; }
		public String title() { return "CPS"; }
		public int width(class_310 mc) { return 62; }
		public int height(class_310 mc) { return 14; }
		public int defaultX() { return 6; }
		public int defaultY() { return 236; }
		public boolean enabledByDefault() { return false; }

		public void render(class_332 g, class_310 mc, boolean preview) {
			panel(g, width(mc), height(mc));
			g.method_51433(mc.field_1772, left() + " | " + right() + " CPS", 6, 3, TEXT, true);
		}
	}

	// ---------------------------------------------------------------- FPS
	public static final class Fps extends HudModule {
		public String id() { return "fps"; }
		public String title() { return "FPS"; }
		public int width(class_310 mc) { return 52; }
		public int height(class_310 mc) { return 14; }
		public int defaultX() { return 6; }
		public int defaultY() { return 6; }

		public void render(class_332 g, class_310 mc, boolean preview) {
			panel(g, width(mc), height(mc));
			g.method_51433(mc.field_1772, mc.method_47599() + " FPS", 6, 3, TEXT, true);
		}
	}

	// ---------------------------------------------------------------- Coordinates
	public static final class Coordinates extends HudModule {
		public String id() { return "coords"; }
		public String title() { return "Coordinates"; }
		public int width(class_310 mc) { return 104; }
		public int height(class_310 mc) { return 36; }
		public int defaultX() { return 6; }
		public int defaultY() { return 24; }

		public void render(class_332 g, class_310 mc, boolean preview) {
			panel(g, width(mc), height(mc));
			double x = 0, y = 64, z = 0;
			String dir = "north";
			if (mc.field_1724 != null) {
				x = mc.field_1724.method_23317();
				y = mc.field_1724.method_23318();
				z = mc.field_1724.method_23321();
				dir = mc.field_1724.method_5735().method_10151();
			}
			g.method_51433(mc.field_1772, String.format("X %.1f", x), 6, 3, TEXT, true);
			g.method_51433(mc.field_1772, String.format("Y %.1f", y), 6, 13, TEXT, true);
			g.method_51433(mc.field_1772, String.format("Z %.1f", z), 6, 23, TEXT, true);
			g.method_51433(mc.field_1772, dir, 72, 13, DIM, true);
		}
	}

	// ---------------------------------------------------------------- Potion effects
	public static final class Potions extends HudModule {
		public String id() { return "potions"; }
		public String title() { return "Potion effects"; }
		public int width(class_310 mc) { return 110; }
		public int height(class_310 mc) { return Math.max(1, rows(mc, true).size()) * 11 + 5; }
		public int defaultX() { return 6; }
		public int defaultY() { return 260; }

		private List<String> rows(class_310 mc, boolean preview) {
			List<String> out = new ArrayList<>();
			if (mc.field_1724 != null) {
				Collection<class_1293> fx = mc.field_1724.method_6026();
				for (class_1293 e : fx) {
					int secs = e.method_5584() / 20;
					String name = e.method_5579().comp_349().method_5560().getString();
					out.add(name + " " + (e.method_5578() + 1) + "  " + (e.method_48559() ? "∞" : secs / 60 + ":" + String.format("%02d", secs % 60)));
				}
			} else if (preview) {
				out.add("Speed 2  1:32");
				out.add("Regeneration 1  0:41");
			}
			return out;
		}

		public void render(class_332 g, class_310 mc, boolean preview) {
			List<String> rows = rows(mc, preview);
			if (rows.isEmpty()) return;
			panel(g, width(mc), height(mc));
			for (int i = 0; i < rows.size(); i++) g.method_51433(mc.field_1772, rows.get(i), 6, 3 + i * 11, TEXT, true);
		}
	}

	// ---------------------------------------------------------------- Sprint status
	public static final class SprintStatus extends HudModule {
		public String id() { return "sprint_status"; }
		public String title() { return "Sprint status"; }
		public int width(class_310 mc) { return 92; }
		public int height(class_310 mc) { return 14; }
		public int defaultX() { return 6; }
		public int defaultY() { return 62; }
		public boolean enabledByDefault() { return false; }

		public void render(class_332 g, class_310 mc, boolean preview) {
			panel(g, width(mc), height(mc));
			String s = Config.get().toggleSprint ? (LuminosClient.sprintLatched ? "Sprint: toggled" : "Sprint: ready") : "Sprint: vanilla";
			g.method_51433(mc.field_1772, s, 6, 3, TEXT, true);
		}
	}
}
