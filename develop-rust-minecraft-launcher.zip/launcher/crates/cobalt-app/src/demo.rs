//! Deterministic demo data used by the screenshot renderer (no disk, no network).
use crate::app::{App, DTab, Loadable, Page};
use cobalt_core::{
    accounts::Account,
    content::Entry,
    instances::{Instance, Loader},
    modrinth::{Project, SearchResult},
    news::NewsItem,
    playtime::{Log, Session},
};
use eframe::egui;

fn inst(id: &str, name: &str, mc: &str, loader: Loader, color: u8, hours: f32, last: i64, preset: bool) -> Instance {
    Instance {
        id: id.into(),
        name: name.into(),
        mc_version: mc.into(),
        loader,
        color,
        playtime_secs: (hours * 3600.0) as u64,
        last_played: Some(cobalt_core::store::now_unix() - last),
        preset: preset.then(|| "cobalt-client".to_string()),
        ..Default::default()
    }
}

fn proj(title: &str, desc: &str, author: &str, downloads: u64, kind: &str) -> Project {
    Project { id: title.to_lowercase().replace(' ', "-"), slug: title.to_lowercase().replace(' ', "-"), title: title.into(), description: desc.into(), author: author.into(), downloads, project_type: kind.into(), ..Default::default() }
}

fn entry(name: &str, ver: &str, desc: &str, enabled: bool, linked: bool) -> Entry {
    Entry { file: format!("{}.jar", name.to_lowercase().replace(' ', "-")), display_name: name.into(), version: ver.into(), enabled, linked, project_id: None, icon_url: None, description: desc.into(), size: 1_200_000 }
}

/// Build an app populated with realistic fake data.
pub fn app(ctx: &egui::Context) -> App {
    let mut a = App::new(ctx, false);
    a.settings.setup_done = true;
    a.accounts.add(Account::offline("CobaltPilot"));
    a.accounts.add(Account::offline("Statics"));
    a.accounts.active = 0;
    a.instances = vec![
        inst("cobalt-client", "Cobalt Client", "1.21.4", Loader::Fabric, 0, 42.9, 3600 * 2, true),
        inst("survival", "Survival 2026", "1.21.4", Loader::Fabric, 2, 18.5, 86400, false),
        inst("vanilla", "Vanilla Snapshot", "26.4-snapshot-10", Loader::Vanilla, 4, 3.2, 86400 * 4, false),
        inst("cobblemon", "Cobblemon", "1.21.1", Loader::Fabric, 3, 27.0, 86400 * 2, false),
        inst("pvp", "PvP Practice", "1.8.9", Loader::Vanilla, 6, 9.4, 86400 * 9, false),
    ];
    a.featured = Loadable::Ready(vec![
        proj("Fabulously Optimized", "Beautiful graphics, speedy performance and familiar features in a simple modpack", "robotkoer", 19_500_000, "modpack"),
        proj("Cobblemon Official Modpack", "The official modpack of the Cobblemon mod, for Fabric!", "CobbledStudios", 11_500_000, "modpack"),
        proj("Better MC [FABRIC]", "A proper Vanilla+ modpack — don't play vanilla, play better", "SHXRKIE", 3_700_000, "modpack"),
    ]);
    a.news = Loadable::Ready(vec![
        NewsItem { title: "Minecraft 26.4 Snapshot 10".into(), version: "26.4-snapshot-10".into(), kind: "snapshot".into(), date: "2026-11-17".into(), summary: String::new(), image_url: None },
        NewsItem { title: "Minecraft 26.3 Release".into(), version: "26.3".into(), kind: "release".into(), date: "2026-10-28".into(), summary: String::new(), image_url: None },
        NewsItem { title: "Minecraft 26.3 Release Candidate 1".into(), version: "26.3-rc-1".into(), kind: "snapshot".into(), date: "2026-10-21".into(), summary: String::new(), image_url: None },
        NewsItem { title: "Minecraft 26.3 Pre-Release 4".into(), version: "26.3-pre-4".into(), kind: "snapshot".into(), date: "2026-10-14".into(), summary: String::new(), image_url: None },
    ]);
    // playtime across the last two weeks
    let now = cobalt_core::store::now_unix();
    let hours = [1.5f32, 0.0, 2.2, 3.1, 0.7, 4.5, 2.8, 1.9, 0.0, 2.4, 3.6, 1.1, 2.0, 2.5];
    let ids = ["cobalt-client", "survival", "cobblemon", "cobalt-client", "pvp"];
    let mut log = Log::default();
    for (i, h) in hours.iter().enumerate() {
        if *h > 0.0 {
            log.sessions.push(Session { instance: ids[i % ids.len()].into(), start: now - (13 - i as i64) * 86400 - 600, secs: (*h * 3600.0) as u64 });
        }
    }
    a.playtime = log;
    a.manifest = Loadable::Ready(cobalt_core::mojang::Manifest { latest: cobalt_core::mojang::Latest { release: "1.21.4".into(), snapshot: "26.4-snapshot-10".into() }, versions: vec![] });
    a.discover.results = Loadable::Ready(SearchResult {
        total_hits: 5_321,
        hits: vec![
            proj("Sodium", "The fastest and most compatible rendering optimization mod for Minecraft", "jellysquid3", 255_450_795, "mod"),
            proj("Entity Culling", "Using async path-tracing to hide Block-/Entities that are not visible", "tr7zw", 191_623_096, "mod"),
            proj("Mod Menu", "Adds a mod menu to view the list of mods you have installed", "Prospector", 163_236_873, "mod"),
            proj("Lithium", "No-compromises game logic optimization mod", "jellysquid3", 145_665_544, "mod"),
            proj("AppleSkin", "Adds hunger-related features to the HUD of the game", "squeek502", 100_255_805, "mod"),
            proj("Iris Shaders", "A modern shader pack loader designed for compatibility with Sodium", "coderbot", 196_932_931, "mod"),
            proj("Armor Hud", "Shows your equipped armour and its durability on screen", "mod_author", 1_379_498, "mod"),
            proj("Zoomify", "A highly configurable zoom mod with smooth transitions", "isxander", 73_447_445, "mod"),
            proj("FerriteCore", "Memory usage optimizations", "malte0811", 169_643_029, "mod"),
        ],
    });
    a.discover.target = Some("cobalt-client".into());
    a.detail.entries = vec![
        entry("Armor Hud", "1.4.2", "Shows your equipped armour and its durability on screen", true, true),
        entry("AppleSkin", "3.0.5", "Adds hunger-related features to the HUD of the game", true, true),
        entry("Entity Culling", "1.7.4", "Using async path-tracing to hide entities that are not visible", true, true),
        entry("FerriteCore", "7.0.1", "Memory usage optimizations", true, true),
        entry("Lithium", "0.14.3", "No-compromises game logic optimization mod", true, true),
        entry("Mod Menu", "11.0.3", "Adds a mod menu to view the list of mods you have installed", true, true),
        entry("Sodium", "0.6.5", "The fastest and most compatible rendering optimization mod", true, true),
        entry("Iris Shaders", "1.8.1", "A modern shader pack loader designed for Sodium", false, true),
        entry("My Custom Tweaks", "", "", true, false),
    ];
    a.skins.lib.skins = vec![
        cobalt_core::skins::SkinEntry { id: "demo-a".into(), name: "Cobalt Blue".into(), slim: false, source: "Studio".into(), added: 0 },
        cobalt_core::skins::SkinEntry { id: "demo-b".into(), name: "Notch".into(), slim: false, source: "Minotar".into(), added: 0 },
        cobalt_core::skins::SkinEntry { id: "demo-c".into(), name: "Alex Mix".into(), slim: true, source: "MC-Heads".into(), added: 0 },
    ];
    for (i, id) in ["demo-a", "demo-b", "demo-c"].iter().enumerate() {
        let px: Vec<egui::Color32> = crate::pages::skins::default_skin()
            .into_iter()
            .map(|c| match i {
                1 => egui::Color32::from_rgba_premultiplied(c.b(), c.g(), c.r(), c.a()),
                2 => egui::Color32::from_rgba_premultiplied(c.g(), c.b(), c.r(), c.a()),
                _ => c,
            })
            .collect();
        a.skins.tex.insert(id.to_string(), ctx.load_texture(format!("demo-skin-{id}"), egui::ColorImage::new([64, 64], px), egui::TextureOptions::NEAREST));
    }
    a.skins.selected = Some("demo-a".into());
    a.detail.tab = DTab::Content;
    a.page = Page::Home;
    a
}
