//! Cobalt Launcher UI. Everything that draws lives here so the same code powers the desktop app
//! (`cobalt`) and the headless screenshot renderer (`cobalt-shots`).
pub mod app;
pub mod demo;
pub mod dither;
pub mod icons;
pub mod pages;
pub mod theme;
pub mod widgets;

pub use app::App;
