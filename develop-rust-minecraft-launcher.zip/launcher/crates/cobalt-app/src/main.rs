#![cfg_attr(all(not(debug_assertions), target_os = "windows"), windows_subsystem = "windows")]

use cobalt_app::App;
use eframe::egui;

fn main() -> eframe::Result<()> {
    cobalt_core::paths::root();
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Cobalt Launcher")
            .with_inner_size([1240.0, 780.0])
            .with_min_inner_size([980.0, 620.0])
            .with_decorations(false)
            .with_transparent(false),
        ..Default::default()
    };
    eframe::run_native("Cobalt Launcher", options, Box::new(|cc| Ok(Box::new(App::new(&cc.egui_ctx, true)))))
}
